/* ===================================================================================
    Departamento Eng. Informatica - FCTUC
    Computacao Grafica - 2021/22
    Meta 1 do Projeto
    Autor: Paulo Cortesão, 2019216517
======================================================================================= */
#ifndef CG_LIB_H
#define CG_LIB_H
#include "colour.h"
#include "cuboid.h"
#include "geoTransform.h"
#include "point.h"
#include "polygon.h"
#endif