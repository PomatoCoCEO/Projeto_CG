echo $1
echo $2
g++ $1 -o $2 -lglut -lGL -lGLU